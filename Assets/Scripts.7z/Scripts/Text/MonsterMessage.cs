﻿public class MonsterMessage : TextMessage
{
    public MonsterMessage(string text)
        : base(text, false, false)
    {
    }
}