﻿using UnityEngine;

public class UIStats : MonoBehaviour {
    public static UIStats instance;

    private GameObject nameLevelTextManParent;
    private TextManager nameLevelTextMan;
    private GameObject hpTextManParent;
    private TextManager hpTextMan;
    private LifeBarController lifebar;
    private RectTransform lifebarRt;

    private bool initialized = false;

    void Awake() { instance = this; }

    private void Start() {
        GameObject statsObj = GameObject.Find("Stats");
        lifebar = statsObj.GetComponentInChildren<LifeBarController>();
        lifebarRt = lifebar.GetComponent<RectTransform>();

        nameLevelTextManParent = GameObject.Find("NameLv");
        nameLevelTextManParent.transform.position = new Vector3(nameLevelTextManParent.transform.position.x, nameLevelTextManParent.transform.position.y - 1, nameLevelTextManParent.transform.position.z);
        hpTextManParent = GameObject.Find("HPTextParent");
        hpTextManParent.transform.position = new Vector3(hpTextManParent.transform.position.x, hpTextManParent.transform.position.y - 1, hpTextManParent.transform.position.z);

        nameLevelTextMan = nameLevelTextManParent.AddComponent<TextManager>();
        hpTextMan = hpTextManParent.AddComponent<TextManager>();

        hpTextMan.setFont(SpriteFontRegistry.Get(SpriteFontRegistry.UI_SMALLTEXT_NAME));
        initialized = true;
        setMaxHP();
        setHP(PlayerCharacter.instance.HP);
        setPlayerInfo(PlayerCharacter.instance.Name, PlayerCharacter.instance.LV);
    }

    public void setPlayerInfo(string name, int lv) {
        if (initialized) {
            nameLevelTextMan.enabled = true;
            nameLevelTextMan.setFont(SpriteFontRegistry.Get(SpriteFontRegistry.UI_SMALLTEXT_NAME));
            nameLevelTextMan.setText(new TextMessage(name.ToUpper() + "  LV " + lv, false, true));
            //RectTransform[] letters = nameLevelTextManParent.GetComponentsInChildren<RectTransform>();
            //GameObject.Find("HPRect").transform.position = new Vector3(letters[letters.Length - 1].position.x + (letters[letters.Length - 1].sizeDelta.x / 2) + 31, 
            //                                                           GameObject.Find("HPRect").transform.position.y, GameObject.Find("HPRect").transform.position.z);
            if (PlayerCharacter.instance.Name.Length > 6)
                GameObject.Find("HPRect").transform.position = new Vector3(GameObject.Find("HPRect").transform.parent.position.x + 286.1f, 
                                                                           GameObject.Find("HPRect").transform.position.y, GameObject.Find("HPRect").transform.position.z);
            else
                GameObject.Find("HPRect").transform.position = new Vector3(GameObject.Find("HPRect").transform.parent.position.x + 215.1f,
                                                                           GameObject.Find("HPRect").transform.position.y, GameObject.Find("HPRect").transform.position.z);

            nameLevelTextMan.enabled = false;
        }
    }

    public void setHP(float hpCurrent) {
        if (initialized) {
            float hpMax = (float)PlayerCharacter.instance.MaxHP,
                  hpFrac = hpCurrent / hpMax;
            lifebar.setInstant(hpFrac);
            int count = UnitaleUtil.DecimalCount(hpCurrent);
            string sHpCurrent = hpCurrent < 10 ? "0" + hpCurrent.ToString("F" + count) : hpCurrent.ToString("F" + count);
            string sHpMax = hpMax < 10 ? "0" + hpMax : "" + hpMax;
            //Debug.Log(count + " --> " + hpCurrent.ToString("F" + count));
            hpTextMan.setText(new TextMessage(sHpCurrent + " / " + sHpMax, false, true));
        }
    }

    public void setMaxHP() {
        if (initialized) {
            if (PlayerCharacter.instance.MaxHP >= 100)
                lifebarRt.sizeDelta = new Vector2(120, lifebarRt.sizeDelta.y);
            else
                lifebarRt.sizeDelta = new Vector2(PlayerCharacter.instance.MaxHP * 1.2f, lifebarRt.sizeDelta.y);
            setHP(PlayerCharacter.instance.HP);
        }
    }
}