﻿using UnityEngine;
using System.Collections;

/// <summary>
/// Lua binding to manipulate in-game music and play sounds.
/// </summary>
public class MusicManager {
    public static MusicManager instance;
    public static AudioSource src;
    public static Hashtable hiddenDictionary = new Hashtable();
    public static string filename = "empty";

    public static float totaltime {
        get { return src.clip.length; }
    }

    public static bool isStoppedOrNull(AudioSource audio) {
        if (audio != null) {
            if (audio.ToString().ToLower() == "null")  return true;
            if (!audio.isPlaying)                      return true;
            else                                       return false;
        }
        return true;
    }

    public static void LoadFile(string name) {
        src.Stop();
        src.clip = AudioClipRegistry.GetMusic(name);
        filename = "music:" + name.ToLower();
        NewMusicManager.audioname["src"] = filename;
        src.Play();
    }

    public static void PlaySound(string name, float volume = 0.65f) {
        try { AudioSource.PlayClipAtPoint(AudioClipRegistry.GetSound(name), Camera.main.transform.position, volume); }
        catch {  }
    }

    public static void Pitch(float value) {
        if (value < -3)
            value = -3;
        if (value > 3)
            value = 3;
        src.pitch = value;
    }

    public static void Volume(float value) {
        if (value < 0)
            value = 0;
        if (value > 1)
            value = 1;
        src.volume = value;
    }

    public static void Play() { src.Play(); }
    public static void Stop() { src.Stop(); }
    public static void Pause() { src.Pause(); }
    public static void Unpause() { src.UnPause(); }

    public static float playtime {
        get { return src.time; }
        set { src.time = value; }
    }

    public static void StopAll() {
        foreach (AudioSource audioSrc in GameObject.FindObjectsOfType<AudioSource>())
            audioSrc.Stop();
    }

    public static void PauseAll() {
        foreach (AudioSource audioSrc in GameObject.FindObjectsOfType<AudioSource>())
            audioSrc.Pause();
    }

    public static void UnpauseAll() {
        foreach (AudioSource audioSrc in GameObject.FindObjectsOfType<AudioSource>())
            audioSrc.UnPause();
    }

    public static string GetSoundDictionary(string key) {
        if (hiddenDictionary.ContainsKey(key.ToLower()))  return (string)hiddenDictionary[key.ToLower()];
        else                                              return key;     
    }

    public static void SetSoundDictionary(string key, string value) {
        if (key == "RESETDICTIONARY")
            hiddenDictionary.Clear();
        else {
            key = key.ToLower();
            if (hiddenDictionary.ContainsKey(key))
                hiddenDictionary.Remove(key);
            hiddenDictionary.Add(key, value);
        }
    }

    //[System.Runtime.CompilerServices.IndexerName("SoundDictionary")]
    public string this[string key] {
        get { return GetSoundDictionary(key); }
        set { SetSoundDictionary(key, value); }
    }
}