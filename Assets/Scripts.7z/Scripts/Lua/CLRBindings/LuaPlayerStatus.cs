﻿using UnityEngine;
/// <summary>
/// Lua binding to set and retrieve information for the on-screen player.
/// </summary>
public class LuaPlayerStatus {
    /// <summary>
    /// This Lua controller's attached PlayerController.
    /// </summary>
    protected PlayerController player;

    /// <summary>
    /// The sprite controller for the player.
    /// </summary>
    private LuaSpriteController spr;

    /// <summary>
    /// Create a new Lua controller intended for this player.
    /// </summary>
    /// <param name="p">PlayerController this controller is intended for</param>
    public LuaPlayerStatus(PlayerController p) {
        player = p;
        spr = new LuaSpriteController(p.GetComponent<UnityEngine.UI.Image>(), p.GetComponent<AutoloadResourcesFromRegistry>().SpritePath.ToLower());
    }

    /// <summary>
    /// Get player's X position relative to the arena's center.
    /// </summary>
    public float x {
        get { return player.self.anchoredPosition.x - ArenaManager.arenaCenter.x; }
    }

    /// <summary>
    /// Get player's Y position relative to the arena's center.
    /// </summary>
    public float y {
        get { return player.self.anchoredPosition.y - ArenaManager.arenaCenter.y; }
    }

    /// <summary>
    /// Get player's X position relative to the bottom left of the screen.
    /// </summary>
    public float absx {
        get { return player.self.anchoredPosition.x; }
    }

    /// <summary>
    /// Get player's Y position relative to the bottom left of the screen.
    /// </summary>
    public float absy {
        get { return player.self.anchoredPosition.y; }
    }

    /// <summary>
    /// Sprite controller for the player soul.
    /// </summary>
    public LuaSpriteController sprite {
        get { return spr; }
    }

    /// <summary>
    /// Get player's current HP.
    /// </summary>
    public float hp {
        get { return player.HP; }
        set { player.setHP(value); }
    }
    
    /// <summary>
    /// Get player's current ATK.
    /// </summary>
    public int atk {
        get { return PlayerCharacter.instance.ATK; }
    }

    /// <summary>
    /// Get player's current ArmorATK.
    /// </summary>
    public int weaponatk {
        get { return PlayerCharacter.instance.WeaponATK; }
    }
    
    /// <summary>
    /// Get player's current DEF.
    /// </summary>
    public int def {
        get { return PlayerCharacter.instance.DEF; }
    }

    /// <summary>
    /// Get player's current ArmorDEF.
    /// </summary>
    public int armordef {
        get { return PlayerCharacter.instance.ArmorDEF; }
    }

    /// <summary>
    /// Player character's name.
    /// </summary>
    public string name {
        get { return PlayerCharacter.instance.Name; }
        set {
            string shortName = value;
            if (shortName.Length > 9)
                shortName = value.Substring(0, 9);
            PlayerCharacter.instance.Name = shortName;
            UIStats.instance.setPlayerInfo(shortName, PlayerCharacter.instance.LV);
        }
    }

    /// <summary>
    /// Player character's level. Adjusts stats when set.
    /// </summary>
    public int lv {
        get { return PlayerCharacter.instance.LV; }
        set {
            if (PlayerCharacter.instance.LV != value) {
                if (PlayerCharacter.instance.HP > PlayerCharacter.instance.MaxHP * 1.5 && PlayerCharacter.instance.LV > value)
                    player.setHP((int)(PlayerCharacter.instance.MaxHP * 1.5));
                PlayerCharacter.instance.SetLevel(value);
                UIStats.instance.setPlayerInfo(PlayerCharacter.instance.Name, PlayerCharacter.instance.LV);
                UIStats.instance.setMaxHP();
            }
        }
    }

    public int lastenemychosen {
        get { return player.lastEnemyChosen; }
    }

    public float lasthitmultiplier {
        get { return player.lastHitMult; }
    }

    /// <summary>
    /// True if player is currently blinking and invincible, false otherwise.
    /// </summary>
    public bool isHurting {
        get { return player.isHurting(); }
    }

    /// <summary>
    /// True if player is currently moving, false otherwise. Being pushed by the edges of the arena counts as moving.
    /// </summary>
    public bool isMoving {
        get { return player.isMoving(); }
    }

    /// <summary>
    /// Player's Max Hp shift.
    /// </summary>
    public int MaxHPShift {
        get { return PlayerCharacter.instance.MaxHPShift; }
    }

    /// <summary>
    /// Hurts the player with the given damage and invulnerabilty time. If this gets the player to 0 (or less) HP, you get the game over screen.
    /// </summary>
    /// <param name="damage">Damage to deal to the player</param>
    /// <param name="invulTime">Invulnerability time in seconds</param>
    /// <param name="ignoreDef">Will the damage ignore the player's defense?</param>
    public void Hurt(float damage, float invulTime = 1.7f, bool ignoreDef = false) { player.Hurt(damage, invulTime, ignoreDef); }

    /// <summary>
    /// Heals the player. Convenience method which is the same as hurting the player for -damage and no invulnerability time.
    /// </summary>
    /// <param name="heal">Value to heal the player for</param>
    public void Heal(float heal) { player.Hurt(-heal, 0.0f); }

    /// <summary>
    /// Override player control. Note: this will disable all movement checking on the player, making it ignore the arena walls.
    /// </summary>
    /// <param name="overrideControl"></param>
    public void SetControlOverride(bool overrideControl) {
        if (UIController.instance.getState() == UIController.UIState.DEFENDING) player.setControlOverride(overrideControl);
    }

    /// <summary>
    /// Move the player relative to the arena center.
    /// </summary>
    /// <param name="x">X position of player relative to arena center.</param>
    /// <param name="y">Y position of player relative to arena center.</param>
    /// <param name="ignoreWalls">If false, it will place you at the edge of the arena instead of over it.</param>
    public void MoveTo(float x, float y, bool ignoreWalls) { MoveToAbs(ArenaManager.arenaCenter.x + x, ArenaManager.arenaCenter.y + y, ignoreWalls); }

    /// <summary>
    /// Move the player relative to his current position
    /// </summary>
    /// <param name="x"></param>
    /// <param name="y"></param>
    /// <param name="ignoreWalls"></param>
    public void Move(float x, float y, bool ignoreWalls) { player.SetPosition(this.x + x, this.y + y, ignoreWalls); }

    /// <summary>
    /// Move the player relative to the lower left corner of the screen.
    /// </summary>
    /// <param name="x">X position of player relative to the lower left of the screen.</param>
    /// <param name="y">Y position of player relative to the lower left of the screen.</param>
    /// <param name="ignoreWalls">If false, it will place you at the edge of the arena instead of over it.</param>
    public void MoveToAbs(float x, float y, bool ignoreWalls) { player.SetPosition(x, y, ignoreWalls); }

    /// <summary>
    /// Sets the player's HP above his HP Max. Maximum : 150% HP Max.
    /// </summary>
    public void ForceHP(float HP) { player.setHP(HP, false); }

    /// <summary>
    /// Sets a shift for the player's Max HP. Can be settable and can modify the player's HP.
    /// </summary>
    /// <param name="shift"></param>
    /// <param name="set"></param>
    /// <param name="canHeal"></param>
    public void setMaxHPShift(int shift, float invulSec = 1.7f, bool set = false, bool canHeal = false) { player.setMaxHPShift(shift, invulSec, set, canHeal); }

    public void changeTarget(int index) {
        if (UIController.instance.state == UIController.UIState.ATTACKING)
            if (index <= UIController.instance.encounter.enabledEnemies.Length && index > 0)
                UIController.instance.fightUI.ChangeTarget(UIController.instance.encounter.enabledEnemies[index-1]);
            else
                UnitaleUtil.displayLuaError("Changing the target", "The enemy number " + index + " doesn't exists.");
    }

    public void ForceAttack(int enemyNumber, int damage = -478294) {
        if (enemyNumber <= UIController.instance.encounter.enabledEnemies.Length && enemyNumber > 0) {
            //UIController.instance.SwitchState(UIController.UIState.ATTACKING);
            UIController.instance.fightUI.targetNumber = 1;
            UIController.instance.fightUI.targetIDs = new int[] { enemyNumber - 1 };
            UIController.instance.fightUI.quickInit(UIController.instance.encounter.enabledEnemies[enemyNumber - 1], damage);
        } else
            UnitaleUtil.displayLuaError("Force Attack", "The enemy number " + enemyNumber + " doesn't exists.");
    }

    public int[] MultiTarget(int damage) { return MultiTarget(null, new int[] { damage }); }
    public int[] MultiTarget(int[] damage, bool thisIsTheDamageForm) { return MultiTarget(null, damage); }
    public int[] MultiTarget(int[] targets = null, int[] damage = null) {
        if (targets != null) {
            if (targets.Length < 2) {
                UnitaleUtil.displayLuaError("Multi Target", "You must have at least 2 enemies to trigger a multi attack.");
                return null;
            }
            for (int i = 0; i < targets.Length; i++) {
                targets[i]--;
                if (targets[i] >= UIController.instance.encounter.enabledEnemies.Length || targets[i] < 0) {
                    UnitaleUtil.displayLuaError("Multi Target", "The enemy number " + targets[i] + " doesn't exists.");
                    return null;
                }
            }
        }
        UIController.instance.fightUI.multiHit = true;
        if (targets == null) {
            targets = new int[UIController.instance.encounter.enabledEnemies.Length];
            for (int i = 0; i < targets.Length; i++)
                targets[i] = i;
        }
        if (damage != null)
            if (damage.Length != 1 && damage.Length != targets.Length)
                UnitaleUtil.displayLuaError("Multi Target", "You may have as many numbers of damage values as the number of enemies if you're using forced damage," 
                                                          + " or 1 for all enemies at the same time.");

        UIController.instance.fightUI.targetIDs = targets;
        UIController.instance.fightUI.targetNumber = targets.Length;
        if (damage != null) {
            if (damage.Length == 1) {
                int tempDamage = damage[0];
                damage = new int[UIController.instance.fightUI.targetNumber];
                for (int i = 0; i < damage.Length; i++)
                    damage[i] = tempDamage;
            }
            for (int i = 0; i < damage.Length; i++)
                UIController.instance.encounter.enabledEnemies[targets[i]].presetDmg = damage[i];
            /*for (int i = 0; i < targets.Length; i++) {
                Debug.Log((UIController.instance.fightUI.allFightUiInstances.Count - 1 - (targets.Length - 1 - i)) + " / " + (UIController.instance.fightUI.allFightUiInstances.Count - 1));
                UIController.instance.fightUI.allFightUiInstances[UIController.instance.fightUI.allFightUiInstances.Count - 1 - (targets.Length - 1 - i)].Damage = damage[i];
            }*/
        }
        return damage;
    }

    public void ForceMultiAttack(int damage) { ForceMultiAttack(null, new int[] { damage }); }
    public void ForceMultiAttack(int[] damage, bool thisIsTheDamageForm) { ForceMultiAttack(null, damage); }
    public void ForceMultiAttack(int[] targets = null, int[] damage = null) {
        int[] damage2 = MultiTarget(targets, damage);
        if (targets == null) {
            targets = new int[UIController.instance.encounter.enabledEnemies.Length];
            for (int i = 0; i < targets.Length; i++)
                targets[i] = i;
        }
        if (damage != null)
            if (damage.Length == 1) {
                int tempDamage = damage[0];
                damage = new int[targets.Length];
                for (int i = 0; i < damage.Length; i++)
                    damage[i] = tempDamage;
            } else
                damage = damage2;
        UIController.instance.fightUI.quickMultiInit(2.2f, damage);
    }

    public void CheckDeath() {
        UIController.instance.needOnDeath = true;
    }

    public void SetAttackAnim(string[] anim, float frequency = 1 / 6f) {
        if (anim.Length == 0) {
            UIController.instance.fightUI.sliceAnim = new string[] { "empty" };
            UIController.instance.fightUI.sliceAnimFrequency = 1 / 30f;
        } else {
            UIController.instance.fightUI.sliceAnim = anim;
            UIController.instance.fightUI.sliceAnimFrequency = frequency;
        }
    }

    public void ResetAttackAnim() {
        UIController.instance.fightUI.sliceAnimFrequency = 1 / 6f;
        UIController.instance.fightUI.sliceAnim = new string[] {
            "UI/Battle/spr_slice_o_0",
            "UI/Battle/spr_slice_o_1",
            "UI/Battle/spr_slice_o_2",
            "UI/Battle/spr_slice_o_3",
            "UI/Battle/spr_slice_o_4",
            "UI/Battle/spr_slice_o_5"
        };
    }
}